package com.gwt.demo.client.utils;

import com.google.gwt.junit.client.GWTTestCase;

public class Test1 extends GWTTestCase {

	@Override
	public String getModuleName() {
		// TODO Auto-generated method stub
		return "";
	}
	


}
