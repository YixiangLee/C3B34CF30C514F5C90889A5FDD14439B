package com.gwt.demo.client.utils;

import com.google.gwt.junit.client.GWTTestCase;

public class TestJSON extends GWTTestCase {

	@Override
	public String getModuleName() {
		// TODO Auto-generated method stub
		//return "com.gwt.demo.CcyMonitoring";
		return "ccymonitoring";
	}
	
	public void testJSON(){

	}

}
