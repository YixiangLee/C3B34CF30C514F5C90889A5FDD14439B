package com.gwt.demo.client.ui;

public final class PageFactory {

	private static Page pIndex;

	public static Page getPage(String pagename) {

		switch (pagename) {
		case "INDEX":
			pIndex = new PageIndex();
			break;
		default:
			pIndex = new PageIndex();
			break;
		}

		return pIndex;
	}
}
