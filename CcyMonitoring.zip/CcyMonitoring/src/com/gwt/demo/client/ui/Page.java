package com.gwt.demo.client.ui;

public interface Page {
	
	public void layout();

}
