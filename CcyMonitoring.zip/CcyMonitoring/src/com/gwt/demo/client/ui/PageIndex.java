package com.gwt.demo.client.ui;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

import com.google.gwt.core.client.JsonUtils;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyCodes;
import com.google.gwt.event.dom.client.KeyDownEvent;
import com.google.gwt.event.dom.client.KeyDownHandler;
import com.google.gwt.http.client.Request;
import com.google.gwt.http.client.RequestBuilder;
import com.google.gwt.http.client.RequestCallback;
import com.google.gwt.http.client.RequestException;
import com.google.gwt.http.client.Response;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.i18n.client.NumberFormat;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HasHorizontalAlignment;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.gwt.demo.client.json.JSONCCYSource;
import com.gwt.demo.client.json.JSONCurrencyBean;
import com.gwt.demo.client.utils.CCYLogger;

public class PageIndex implements Page {

	private VerticalPanel mainPanel = new VerticalPanel();
	private FlexTable ccyFlexTable = new FlexTable();
	private FlexTable ccyHisFlexTable = new FlexTable();
	private HorizontalPanel addPanel = new HorizontalPanel();
	private TextBox newCcyTextBox = new TextBox();
	private Button addCcyButton = new Button("Add Currency");
	private Button refreshCcyButton = new Button("Refresh Currency Data");
	private Button calcDiffButton = new Button("Calc. Ratio");
	private Label lastUpdatedLabel = new Label();
	private JSONCurrencyBean JSONBean;
	private Button removeButton = new Button("Remove Currency");

	private static List<String> ccyBucket = new ArrayList<String>();
	private static Map<String, JSONCurrencyBean> ccyBeanMap = new HashMap<String, JSONCurrencyBean>();

	static {
		ccyBucket.add("CNY");
		ccyBucket.add("EUR");
		ccyBucket.add("USD");
		ccyBucket.add("JPY");
	}

	@Override
	public void layout() {
		CCYLogger.getClientLogger().log(Level.INFO, "Init");
		ccyFlexTable.setText(0, 0, "Reporting Date");
		ccyFlexTable.setText(0, 1, "Currency");
		ccyFlexTable.setText(0, 2, "Rate(HKD equivalent)");
		ccyFlexTable.setText(0, 3, "Change(Last 30 days)");

		ccyHisFlexTable.setText(0, 0, "His Reporting Date");
		ccyHisFlexTable.setText(0, 1, "His CCY");
		ccyHisFlexTable.setText(0, 2, "His Rate (HKD equivalent)");
		CCYLogger.getClientLogger().log(Level.SEVERE, "Init finisheds");

		refreshHisCCY(JSONCCYSource.getLastMonDate());

		refreshCCY(JSONCCYSource.getCurrentDate());
	

		addPanel.add(newCcyTextBox);
		addPanel.add(addCcyButton);
		addPanel.add(removeButton);
		addPanel.add(refreshCcyButton);
		addPanel.add(calcDiffButton);
		// Assemble Main panel.
		mainPanel.add(ccyFlexTable);
		mainPanel.add(ccyHisFlexTable);
		mainPanel.add(addPanel);
		mainPanel.add(lastUpdatedLabel);

		RootPanel.get("ccyList").add(mainPanel);
		// Move cursor focus to the input box.
		newCcyTextBox.setFocus(true);
		ccyFlexTable.getRowFormatter().addStyleName(0, "ccyListHeader");
		ccyHisFlexTable.setVisible(false);

		removeButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {

				for (int i = 1; i < ccyFlexTable.getRowCount(); i++) {
					if (newCcyTextBox.getText().toUpperCase().equals(ccyFlexTable.getText(i, 1))) {

						ccyFlexTable.removeRow(i);
						ccyHisFlexTable.removeRow(i);
						break;
					}

				}
				CCYLogger.getClientLogger().log(Level.SEVERE,  ccyFlexTable.getRowCount()+"");
			}
		});

		addCcyButton.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent event) {
				if(!verifyInputs())return;
				for (int i = 1; i < ccyFlexTable.getRowCount(); i++) {
					if (newCcyTextBox.getText().toUpperCase().equals(ccyFlexTable.getText(i, 1))) {
						return;
					}

				}
				int k  = ccyFlexTable.insertRow(ccyFlexTable.getRowCount());
				
				ccyFlexTable.setText(k, 0,ccyBeanMap.get("Current").getDate() );
				ccyFlexTable.setText(k, 1,newCcyTextBox.getText().toUpperCase());
				ccyFlexTable.setText(k, 2,ccyBeanMap.get("Current").getRates().getPrice(newCcyTextBox.getText().toUpperCase())+"" );
				
				int h  = ccyHisFlexTable.insertRow(ccyHisFlexTable.getRowCount());
				
				ccyHisFlexTable.setText(h, 0,ccyBeanMap.get("Previous").getDate() );
				ccyHisFlexTable.setText(h, 1,newCcyTextBox.getText().toUpperCase());
				ccyHisFlexTable.setText(h, 2,ccyBeanMap.get("Previous").getRates().getPrice(newCcyTextBox.getText().toUpperCase())+"" );
				
				CCYLogger.getClientLogger().log(Level.SEVERE,  ccyFlexTable.getRowCount()+"");
			}
		});

		// Listen for keyboard events in the input box.
//		newCcyTextBox.addKeyDownHandler(new KeyDownHandler() {
//			public void onKeyDown(KeyDownEvent event) {
//				if (event.getNativeKeyCode() == KeyCodes.KEY_ENTER) {
//					if(!verifyInputs())return;
//				}
//			}
//		});

		refreshCcyButton.addClickHandler(new ClickHandler() {

			@Override
			public void onClick(ClickEvent event) {
				refreshHisCCY(JSONCCYSource.getLastMonDate());
				refreshCCY(JSONCCYSource.getCurrentDate());

			}

		});
		
		calcDiffButton.addClickHandler(new ClickHandler(){

			@Override
			public void onClick(ClickEvent event) {
				calcCCYDiff();
				
			}
			
		});

	}

	private void calcCCYDiff() {
		for (int i = 1; i < ccyFlexTable.getRowCount(); i++) {
			double currRate = Double.valueOf(ccyFlexTable.getText(i, 2));
			double lastRate = Double.valueOf(ccyHisFlexTable.getText(i, 2));
			double ratio = (currRate - lastRate) / lastRate;
			NumberFormat fmt = NumberFormat.getFormat("##.##%");
			this.ccyFlexTable.setText(i, 3, fmt.format(ratio));
		}

	}

	private void refreshCCY(String d) {
		// current CCY first
		RequestBuilder rbd = JSONCCYSource.getCCYRate(d);
		try {
			Request req = rbd.sendRequest(null, new RequestCallback() {

				@Override
				public void onResponseReceived(Request request, Response response) {
					if (200 != response.getStatusCode()) {
						CCYLogger.getClientLogger().log(Level.SEVERE, "Response error : " + response.getStatusText());
						return;
					}
					JSONBean = JsonUtils.safeEval(response.getText());

					initCurrFlexTables(ccyFlexTable, JSONBean);

					// initHisFlexTables(ccyHisFlexTable, JSONBean);
					ccyBeanMap.put("Current", JSONBean);
					lastUpdatedLabel.setText("Last updated : "+DateTimeFormat.getFormat(DateTimeFormat.PredefinedFormat.DATE_TIME_MEDIUM).format(new Date()));
				}

				@Override
				public void onError(Request request, Throwable exception) {
					CCYLogger.getClientLogger().log(Level.SEVERE, "Response exception : " + exception.getMessage());

				}

			});
		} catch (RequestException e) {
			CCYLogger.getClientLogger().log(Level.SEVERE, "Request exception : " + e.getMessage());

		}
	}

	private void refreshHisCCY(String d) {
		// current CCY first
		RequestBuilder rbd = JSONCCYSource.getCCYRate(d);
		try {
			Request req = rbd.sendRequest(null, new RequestCallback() {

				@Override
				public void onResponseReceived(Request request, Response response) {
					if (200 != response.getStatusCode()) {
						CCYLogger.getClientLogger().log(Level.SEVERE, "Response error : " + response.getStatusText());
						return;
					}
					JSONBean = JsonUtils.safeEval(response.getText());

					initHisFlexTables(ccyHisFlexTable, JSONBean);
					ccyBeanMap.put("Previous", JSONBean);
				}

				@Override
				public void onError(Request request, Throwable exception) {
					CCYLogger.getClientLogger().log(Level.SEVERE, "Response exception : " + exception.getMessage());

				}

			});
		} catch (RequestException e) {
			CCYLogger.getClientLogger().log(Level.SEVERE, "Request exception : " + e.getMessage());

		}
	}

	private void initCurrFlexTables(FlexTable ftb, JSONCurrencyBean jcb) {
		if (jcb == null) {
			ftb.setText(1, 0, " -- ");
			ftb.setText(1, 1, " -- ");
			ftb.setText(1, 2, " -- ");
			ftb.setText(1, 3, " -- ");
			return;
		}
		for(int i = 1; i < ftb.getRowCount(); i++){
			ftb.removeRow(i);
		}
		ftb.setText(1, 0, jcb.getDate());
		ftb.setText(1, 1, "CNY");
		ftb.setText(1, 2, jcb.getRates().getCNYPrice() + "");
		ftb.setText(1, 3, " -- ");

		ftb.setText(2, 0, jcb.getDate());
		ftb.setText(2, 1, "EUR");
		ftb.setText(2, 2, jcb.getRates().getEURPrice() + "");
		ftb.setText(2, 3, "--");

		ftb.setText(3, 0, jcb.getDate());
		ftb.setText(3, 1, "USD");
		ftb.setText(3, 2, jcb.getRates().getUSDPrice() + "");
		ftb.setText(3, 3, "--");

		ftb.setText(4, 0, jcb.getDate());
		ftb.setText(4, 1, "JPY");
		ftb.setText(4, 2, jcb.getRates().getJPYPrice() + "");
		ftb.setText(4, 3, "--");

	}

	private void initHisFlexTables(FlexTable ftb, JSONCurrencyBean jcb) {
		if (jcb == null) {
			ftb.setText(1, 0, " -- ");
			ftb.setText(1, 1, " -- ");
			ftb.setText(1, 2, " -- ");
			return;
		}
		
		for(int i = 1; i < ftb.getRowCount(); i++){
			ftb.removeRow(i);
		}

		ftb.setText(1, 0, jcb.getDate());
		ftb.setText(1, 1, "CNY");
		ftb.setText(1, 2, jcb.getRates().getCNYPrice() + "");

		ftb.setText(2, 0, jcb.getDate());
		ftb.setText(2, 1, "EUR");
		ftb.setText(2, 2, jcb.getRates().getEURPrice() + "");

		ftb.setText(3, 0, jcb.getDate());
		ftb.setText(3, 1, "USD");
		ftb.setText(3, 2, jcb.getRates().getUSDPrice() + "");

		ftb.setText(4, 0, jcb.getDate());
		ftb.setText(4, 1, "JPY");
		ftb.setText(4, 2, jcb.getRates().getJPYPrice() + "");

	}

	private boolean verifyInputs() {
		final String symbol = newCcyTextBox.getText().toUpperCase().trim();
		newCcyTextBox.setFocus(true);

		//Hard code CCY list
		if(
			newCcyTextBox.getText().toUpperCase().equals("CNY")	||
			newCcyTextBox.getText().toUpperCase().equals("GBP")	||
			newCcyTextBox.getText().toUpperCase().equals("USD")	||
			newCcyTextBox.getText().toUpperCase().equals("JPY")	||
			newCcyTextBox.getText().toUpperCase().equals("EUR")	||
			newCcyTextBox.getText().toUpperCase().equals("SGD")	
				){
			
			return true;
		}else{
			CCYDialog ccD = new CCYDialog("Only following currencies accepted:\n\rCNY\nGBP\nUSD\nJPY\nEUR\nSGD\n");
			int left = Window.getClientWidth()/ 2;
            int top = Window.getClientHeight()/ 2;
            ccD.setPopupPosition(left, top);
			ccD.show();
			return false;
		}


	}
	//Pop up dialog
	private static class CCYDialog extends DialogBox{
		
		public CCYDialog(String message){
			super.setText("CCY Alert");
			super.setAnimationEnabled(true);
			
			Button ok = new Button("OK");
			
			ok.addClickHandler(new ClickHandler(){

				@Override
				public void onClick(ClickEvent event) {
					CCYDialog.this.hide();
					
				}
				
			});
			
			Label msg = new Label(message);
			VerticalPanel diaPanel = new VerticalPanel();
			diaPanel.setHeight("100");
			diaPanel.setWidth("300");
			diaPanel.setSpacing(10);
			diaPanel.setHorizontalAlignment(HasHorizontalAlignment.ALIGN_CENTER);
			diaPanel.add(msg);
			diaPanel.add(ok);

	        super.setWidget(diaPanel);
		}
	}

}
