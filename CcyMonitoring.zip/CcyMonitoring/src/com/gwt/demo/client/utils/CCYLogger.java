package com.gwt.demo.client.utils;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.google.gwt.logging.client.PopupLogHandler;

public final class CCYLogger {
	
	private static Logger clientLogger;
	
	static{
	    clientLogger = Logger.getLogger("CCYLogClient");
	    clientLogger.addHandler(new PopupLogHandler());
	    clientLogger.log(Level.CONFIG, "Logger init..");
	    

	}

	public static Logger getClientLogger(){
		return clientLogger;
	}
	
}
