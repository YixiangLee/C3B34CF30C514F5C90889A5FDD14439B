package com.gwt.demo.client;

import com.google.gwt.core.client.EntryPoint;
import com.gwt.demo.client.ui.Page;
import com.gwt.demo.client.ui.PageFactory;

/**
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class CcyMonitoring implements EntryPoint {
	
	
	private Page pg;
	/**
	 * This is the entry point method.
	 */
	public void onModuleLoad() {
		
		pg = PageFactory.getPage("INDEX");
		pg.layout();
	}
}
