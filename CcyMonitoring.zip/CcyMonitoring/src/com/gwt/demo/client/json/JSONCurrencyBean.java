package com.gwt.demo.client.json;

import com.google.gwt.core.client.JavaScriptObject;

public class JSONCurrencyBean extends JavaScriptObject {
	
	protected JSONCurrencyBean(){
		
	}
	
	public final static class NestedCCY extends JSONCurrencyBean{
		protected NestedCCY(){
			
		}
		public double getPrice(String ccy){
			
			double d = -100;;
			switch(ccy){
			case "CNY" : d = this.getCNYPrice();break;
			case "USD" : d = this.getUSDPrice();break;
			case "JPY" : d = this.getJPYPrice();break;
			case "EUR" : d = this.getEURPrice();break;
			case "GBP" : d = this.getGBPPrice();break;
			case "SGD" : d = this.getSGDPrice();break;
			}
			return d;
		}
		
		public final native double getCNYPrice()/*-{ return this.CNY; }-*/;
		public final native double getUSDPrice()/*-{ return this.USD; }-*/;
		public final native double getJPYPrice()/*-{ return this.JPY; }-*/;
		public final native double getEURPrice()/*-{ return this.EUR; }-*/;
		public final native double getGBPPrice()/*-{ return this.GBP; }-*/;
		public final native double getSGDPrice()/*-{ return this.SGD; }-*/;
	}
	
	public final native String getBase()/*-{ return this.base; }-*/;
	public final native String getDate()/*-{ return this.date; }-*/;
	public final native JSONCurrencyBean.NestedCCY getRates()/*-{ return this.rates; }-*/;
	
	//public final native double getCNYPrice()/*-{ return this.rates.CNY; }-*/;

}
