package com.gwt.demo.client.json;


import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;

import com.google.gwt.http.client.RequestBuilder;
import com.google.gwt.http.client.URL;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.user.datepicker.client.CalendarUtil;
import com.gwt.demo.client.utils.CCYLogger;

public class JSONCCYSource {

	private static String ccy_url = "http://api.fixer.io/2016-01-01?base=HKD";

	
	public final static Map<String,JSONCurrencyBean> CCY_MAP = new HashMap<String,JSONCurrencyBean>();
	

	public static String getCurrentDate(){
		Date d = new Date();
		DateTimeFormat sdf = DateTimeFormat.getFormat("yyyy-MM-dd");
		return sdf.format(d);
	}
	public static String getLastMonDate(){
		Date d = new Date();
		CalendarUtil.addDaysToDate(d, -30);
		DateTimeFormat sdf = DateTimeFormat.getFormat("yyyy-MM-dd");
		return sdf.format(d);
	}
	public static boolean isCurrDate(String date){
		//return date.equals(getCurrentDate())?true:false;
		return true;
	}
	
	public static RequestBuilder getCCYRate(String date){
		
		CCYLogger.getClientLogger().log(Level.SEVERE, "Request Date  : "+ date);

		
		String iURL;

		if(date == null){
			iURL = ccy_url;
		}else{
			iURL = "http://api.fixer.io/"+date+"?base=HKD";
		}
		RequestBuilder rb = new RequestBuilder(RequestBuilder.GET,URL.encode(iURL));
		
	
		return rb;
		
	}

	private JSONCCYSource() {
		
		
	}

}
